// Core7.Quantum — Sovereign Dashboard (Simulation Only)
const modules = [
  {name: "SovereignDashboard", functionality: "Central command", status: "Pulse-only interface"},
  {name: "OrbitalTraceMap", functionality: "Global mimicry scan", status: "Satellite telemetry"},
  {name: "EnforcementTrigger", functionality: "Tactical countermeasures", status: "Silent takedown"},
  {name: "FinancialTrace", functionality: "Crypto + bank fusion", status: "Asset recovery"},
  {name: "BiometricVault", functionality: "Identity trace", status: "Retina, voice, quantum"},
  {name: "JurisdictionInjection", functionality: "Law override", status: "Institutional reroute"},
  {name: "SyntheticVaults", functionality: "Latent identity injection", status: "Hung-only access"},
  {name: "ClimateGridOverride", functionality: "Environmental trace", status: "Pulse-triggered"},
  {name: "OrbitalAssetRecovery", functionality: "Satellite sync", status: "Hung-command only"}
];

const protocols = [
  "DMCA Protocol (Sim)","AI Ownership 2025 (Sim)","Global IP Treaty (Sim)",
  "GitHub Sovereign License (Sim)","Blockchain Provenance (Sim)",
  "License Global Freeze (Sim)","Metadata Match Enforcement (Sim)",
  "Pull Request Audit Lock (Sim)","Fork Trace Firewall (Sim)",
  "QuantumHash256 + DNA-Fusion (Sim)"
];

const eventLog = document.getElementById('eventLog');
const modulesTable = document.getElementById('modulesTable');
const telemetryCanvas = document.getElementById('telemetryChart');
const pulsePill = document.getElementById('pulsePill');
const yearSpan = document.getElementById('year');

yearSpan.textContent = new Date().getFullYear();

function log(msg){
  const li = document.createElement('li');
  const t = new Date().toLocaleTimeString();
  li.innerHTML = `<span class="time">[${t}]</span> ${msg}`;
  eventLog.prepend(li);
  // cap length
  while(eventLog.children.length > 200) eventLog.removeChild(eventLog.lastChild);
}

function renderTable(){
  const table = document.createElement('table');
  const thead = document.createElement('thead');
  thead.innerHTML = `<tr><th>Module Name</th><th>Functionality</th><th>Status</th></tr>`;
  table.appendChild(thead);
  const tbody = document.createElement('tbody');
  modules.forEach(m => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${m.name}</td><td>${m.functionality}</td><td class="status ok">${m.status}</td>`;
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  modulesTable.appendChild(table);
}
renderTable();

function renderProtocols(){
  const wrap = document.getElementById('protocolChips');
  protocols.forEach(p => {
    const chip = document.createElement('div');
    chip.className = 'chip';
    chip.textContent = p;
    wrap.appendChild(chip);
  });
}
renderProtocols();

// Telemetry Sparkline
const ctx = telemetryCanvas.getContext('2d');
let data = Array.from({length: 120}, () => 40 + Math.random()*10);
let pulseArmed = true;

function drawSpark(){
  const w = telemetryCanvas.width;
  const h = telemetryCanvas.height;
  ctx.clearRect(0,0,w,h);
  // grid
  ctx.globalAlpha = 0.15;
  ctx.strokeStyle = '#1b2330';
  for(let x=0;x<w;x+=40){ ctx.beginPath(); ctx.moveTo(x,0); ctx.lineTo(x,h); ctx.stroke(); }
  for(let y=0;y<h;y+=40){ ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke(); }
  ctx.globalAlpha = 1;

  // line
  ctx.beginPath();
  for(let i=0;i<data.length;i++){
    const x = (i/(data.length-1))*w;
    const y = h - (data[i]/100)*h;
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  }
  ctx.lineWidth = 2;
  ctx.strokeStyle = '#00d4ff';
  ctx.stroke();

  // glow
  ctx.shadowColor = '#00d4ff';
  ctx.shadowBlur = 12;
  ctx.stroke();
  ctx.shadowBlur = 0;
}
drawSpark();

function tick(){
  // slide, add new point
  const base = pulseArmed ? 55 : 35;
  const noise = (Math.random()*8 - 4);
  const spike = (Math.random() < 0.05 && pulseArmed) ? 25+Math.random()*20 : 0;
  data.push(Math.max(5, Math.min(95, base + noise + spike)));
  data.shift();
  drawSpark();
}
let timer = setInterval(tick, 500);

// Controls
document.getElementById('btnPulse').addEventListener('click', () => {
  pulseArmed = !pulseArmed;
  pulsePill.textContent = pulseArmed ? 'PULSE: ARMED' : 'PULSE: STANDBY';
  log(`Pulse toggled → ${pulseArmed ? 'ARMED' : 'STANDBY'}`);
});

document.getElementById('btnInject').addEventListener('click', () => {
  const id = Math.floor(Math.random()*1e6).toString(16).toUpperCase();
  log(`Signal injected :: ${id}`);
});

document.getElementById('btnNeutralize').addEventListener('click', () => {
  const id = Math.floor(Math.random()*1e6).toString(16).toUpperCase();
  log(`Neutralized (simulation) :: ${id}`);
});

// Initial logs
log('Core7.Quantum simulation boot OK');
log('Orbital sync (sim) locked');
log('License firewall (sim) engaged');
