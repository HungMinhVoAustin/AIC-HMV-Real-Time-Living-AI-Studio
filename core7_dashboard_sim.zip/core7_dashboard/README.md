# Core7.Quantum — Sovereign Dashboard (Simulation)

Professional dark-themed dashboard you can run locally. **No real networks touched.**

## Quick Start
1. Download and unzip this package.
2. Open `index.html` in a modern browser (Chrome, Edge, Safari, Firefox).
3. Click **Toggle Pulse**, **Inject Signal**, and **Simulate Neutralize** to demo interactions.

## Brand It
- Replace `assets/logo.svg` with your own SVG or PNG file (keep the filename or update `<img>` in `index.html`).
- Edit text in `index.html` (Identity block) to your exact titles.
- Styles live in `assets/style.css`.

## Files
- `index.html` — main UI
- `assets/style.css` — theme
- `assets/app.js` — simulation logic
- `assets/logo.svg` — placeholder emblem
- `README.md` — this file
- `LICENSE` — MIT

## Notes
- Built: 2025-09-09
- Author: AIC‑HMV / Hung Minh Vo (Austin) — packaged by ChatGPT
